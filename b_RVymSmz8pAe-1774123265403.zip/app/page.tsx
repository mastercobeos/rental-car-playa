import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { FleetSection } from "@/components/fleet-section"
import { FeaturesSection } from "@/components/features-section"
import { DestinationsSection } from "@/components/destinations-section"
import { ReviewsSection } from "@/components/reviews-section"
import { FAQSection } from "@/components/faq-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <main>
      <Header />
      <HeroSection />
      <FleetSection />
      <FeaturesSection />
      <DestinationsSection />
      <ReviewsSection />
      <FAQSection />
      <ContactSection />
      <Footer />
    </main>
  )
}
