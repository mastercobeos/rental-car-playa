import type { Metadata } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter',
  display: 'swap',
})

const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: '--font-playfair',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Playa Car Rental | Premium Car Rentals in Playa del Carmen, Mexico',
  description: 'Rent the perfect car for your Riviera Maya adventure. Best prices on SUVs, sedans, and convertibles in Playa del Carmen. Free airport pickup, full insurance, and 24/7 support.',
  keywords: 'car rental playa del carmen, rent a car mexico, riviera maya car rental, cancun airport car rental, cheap car rental quintana roo',
  openGraph: {
    title: 'Playa Car Rental | Premium Car Rentals in Playa del Carmen',
    description: 'Rent the perfect car for your Riviera Maya adventure. Best prices guaranteed.',
    type: 'website',
    locale: 'en_US',
    siteName: 'Playa Car Rental',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Playa Car Rental | Premium Car Rentals',
    description: 'Rent the perfect car for your Riviera Maya adventure.',
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className="font-sans antialiased">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
