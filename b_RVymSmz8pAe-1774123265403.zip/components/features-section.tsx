import { Shield, Clock, DollarSign, Headphones, Car, MapPin } from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Full Insurance Coverage",
    description: "Comprehensive insurance included with every rental. Drive worry-free throughout Mexico.",
  },
  {
    icon: Car,
    title: "Free Airport Pickup",
    description: "We meet you at Cancun Airport with your car ready. No waiting, no hassle.",
  },
  {
    icon: DollarSign,
    title: "No Hidden Fees",
    description: "The price you see is the price you pay. Transparent pricing with no surprises.",
  },
  {
    icon: Clock,
    title: "Flexible Booking",
    description: "Free cancellation up to 48 hours before pickup. Plans change, we understand.",
  },
  {
    icon: Headphones,
    title: "24/7 Road Support",
    description: "English-speaking support team available around the clock for any emergency.",
  },
  {
    icon: MapPin,
    title: "Multiple Locations",
    description: "Pick up in Cancun, drop off in Tulum. Flexible one-way rentals available.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Why Choose Us</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4 text-balance">
            The Best Car Rental Experience in the Riviera Maya
          </h2>
          <p className="text-muted-foreground text-lg">
            We go above and beyond to make your trip unforgettable. Here&apos;s what sets us apart.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="group p-8 rounded-2xl bg-card border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                <feature.icon className="h-7 w-7 text-primary group-hover:text-primary-foreground transition-colors" />
              </div>
              <h3 className="text-xl font-bold text-card-foreground mb-3">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="mt-20 py-12 px-8 rounded-3xl bg-foreground">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">500+</div>
              <p className="text-background/70">Happy Customers</p>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">50+</div>
              <p className="text-background/70">Vehicles in Fleet</p>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">4.9</div>
              <p className="text-background/70">Average Rating</p>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-primary mb-2">8+</div>
              <p className="text-background/70">Years Experience</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
