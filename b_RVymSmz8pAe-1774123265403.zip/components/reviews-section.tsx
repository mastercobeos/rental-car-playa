"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react"
import { cn } from "@/lib/utils"

const reviews = [
  {
    id: 1,
    name: "Sarah Mitchell",
    location: "Austin, Texas",
    rating: 5,
    text: "Best car rental experience I've ever had in Mexico! They picked us up right at the airport terminal, the car was spotless and new. We drove all over the Riviera Maya without any issues. Will definitely use them again!",
    date: "February 2026",
    car: "Toyota RAV4",
  },
  {
    id: 2,
    name: "James & Emily Wilson",
    location: "Denver, Colorado",
    rating: 5,
    text: "We were nervous about renting a car in Mexico, but Playa Car Rental made it so easy. Clear communication, fair pricing, and the Jeep Wrangler was perfect for exploring cenotes. The team even gave us recommendations for hidden spots!",
    date: "January 2026",
    car: "Jeep Wrangler",
  },
  {
    id: 3,
    name: "Michael Thompson",
    location: "Chicago, Illinois",
    rating: 5,
    text: "Transparent pricing with no hidden fees - exactly as advertised. The pickup process was quick, and when we had a flat tire, their support team responded within 30 minutes. Outstanding service!",
    date: "March 2026",
    car: "Nissan Versa",
  },
  {
    id: 4,
    name: "Jennifer Rodriguez",
    location: "Miami, Florida",
    rating: 5,
    text: "As someone who travels to Playa del Carmen frequently, I've tried many rental companies. Playa Car Rental is hands down the best. Professional, reliable, and their cars are always in excellent condition.",
    date: "February 2026",
    car: "Toyota Camry",
  },
  {
    id: 5,
    name: "David & Lisa Chen",
    location: "San Francisco, California",
    rating: 5,
    text: "The Mercedes was immaculate and made our honeymoon extra special. We felt safe and pampered the entire trip. The team went above and beyond to accommodate our late flight arrival. Highly recommend!",
    date: "January 2026",
    car: "Mercedes C-Class",
  },
]

export function ReviewsSection() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextReview = () => {
    setCurrentIndex((prev) => (prev + 1) % reviews.length)
  }

  const prevReview = () => {
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length)
  }

  return (
    <section id="reviews" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Testimonials</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4 text-balance">
            What Our Customers Say
          </h2>
          <p className="text-muted-foreground text-lg">
            Don&apos;t just take our word for it. Here&apos;s what travelers from across the USA have to say about their experience.
          </p>
        </div>

        {/* Reviews Carousel */}
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Main Review Card */}
            <div className="bg-card rounded-3xl p-8 md:p-12 shadow-xl border border-border">
              <Quote className="h-12 w-12 text-primary/20 mb-6" />
              
              <div className="flex items-center gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={cn(
                      "h-5 w-5",
                      i < reviews[currentIndex].rating 
                        ? "text-yellow-400 fill-yellow-400" 
                        : "text-muted"
                    )} 
                  />
                ))}
              </div>

              <p className="text-lg md:text-xl text-card-foreground leading-relaxed mb-8">
                &ldquo;{reviews[currentIndex].text}&rdquo;
              </p>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-6 border-t border-border">
                <div>
                  <p className="font-bold text-card-foreground">{reviews[currentIndex].name}</p>
                  <p className="text-muted-foreground text-sm">{reviews[currentIndex].location}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-primary font-medium">{reviews[currentIndex].car}</p>
                  <p className="text-sm text-muted-foreground">{reviews[currentIndex].date}</p>
                </div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <button
                onClick={prevReview}
                className="w-12 h-12 rounded-full border border-border hover:border-primary hover:bg-primary hover:text-primary-foreground transition-all flex items-center justify-center"
                aria-label="Previous review"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              
              <div className="flex items-center gap-2">
                {reviews.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={cn(
                      "w-2.5 h-2.5 rounded-full transition-all",
                      currentIndex === index 
                        ? "bg-primary w-8" 
                        : "bg-muted hover:bg-muted-foreground/50"
                    )}
                    aria-label={`Go to review ${index + 1}`}
                  />
                ))}
              </div>

              <button
                onClick={nextReview}
                className="w-12 h-12 rounded-full border border-border hover:border-primary hover:bg-primary hover:text-primary-foreground transition-all flex items-center justify-center"
                aria-label="Next review"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-16 flex flex-wrap items-center justify-center gap-8 opacity-70">
          <div className="flex items-center gap-2 text-muted-foreground">
            <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
            <span className="font-medium">Verified Reviews</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
              ))}
            </div>
            <span className="font-medium">4.9 Average Rating</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
            </svg>
            <span className="font-medium">500+ Happy Customers</span>
          </div>
        </div>
      </div>
    </section>
  )
}
