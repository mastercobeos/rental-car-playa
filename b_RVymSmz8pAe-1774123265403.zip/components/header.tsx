"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, Phone, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const navItems = [
    { label: "Fleet", href: "#fleet" },
    { label: "Why Us", href: "#features" },
    { label: "Destinations", href: "#destinations" },
    { label: "Reviews", href: "#reviews" },
    { label: "FAQ", href: "#faq" },
    { label: "Contact", href: "#contact" },
  ]

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
      {/* Top bar */}
      <div className="hidden md:block bg-foreground text-background">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-6">
              <a href="tel:+529841234567" className="flex items-center gap-2 hover:text-primary transition-colors">
                <Phone className="h-4 w-4" />
                +52 984 123 4567
              </a>
              <a href="mailto:info@playacarrental.com" className="flex items-center gap-2 hover:text-primary transition-colors">
                <Mail className="h-4 w-4" />
                info@playacarrental.com
              </a>
            </div>
            <p className="text-background/80">Free Airport Pickup • 24/7 Support</p>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <div className="bg-foreground rounded-lg p-2 flex items-center justify-center">
              <svg viewBox="0 0 180 60" className="h-8 md:h-10 w-auto" fill="white">
                <path d="M30 20c-3 0-5.5 1-7.5 3s-3 4.5-3 7.5 1 5.5 3 7.5 4.5 3 7.5 3h45c1.5-2 2.5-4.5 2.5-7s-1-5-2.5-7H30zm0 3h42c1 1.5 1.5 3 1.5 4.5S73 31 72 32.5H30c-2 0-3.5-.5-5-2s-2-3-2-5 .5-3.5 2-5 3-2 5-2z" />
                <ellipse cx="35" cy="38" rx="6" ry="6" />
                <ellipse cx="65" cy="38" rx="6" ry="6" />
                <text x="90" y="25" fontSize="14" fontWeight="700" letterSpacing="2">PLAYA</text>
                <text x="90" y="42" fontSize="10" fontWeight="400" letterSpacing="1">CAR RENTAL</text>
              </svg>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="text-muted-foreground hover:text-foreground font-medium transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center gap-4">
            <Button variant="outline" asChild>
              <a href="tel:+529841234567">Call Now</a>
            </Button>
            <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Link href="#booking">Book Now</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-border">
            <nav className="flex flex-col gap-4">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  className="text-muted-foreground hover:text-foreground font-medium transition-colors py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <div className="flex flex-col gap-3 pt-4 border-t border-border">
                <Button variant="outline" asChild className="w-full">
                  <a href="tel:+529841234567">Call Now</a>
                </Button>
                <Button asChild className="w-full bg-primary hover:bg-primary/90">
                  <Link href="#booking">Book Now</Link>
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
