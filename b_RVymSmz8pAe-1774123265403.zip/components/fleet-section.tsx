"use client"

import { useState } from "react"
import { Users, Fuel, Settings, Snowflake, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

const categories = [
  { id: "all", label: "All Vehicles" },
  { id: "economy", label: "Economy" },
  { id: "suv", label: "SUV" },
  { id: "sedan", label: "Sedan" },
  { id: "luxury", label: "Luxury" },
]

const vehicles = [
  {
    id: 1,
    name: "Nissan Versa",
    category: "economy",
    price: 29,
    image: "https://images.unsplash.com/photo-1625231334168-24ed5c9e5c47?w=600&h=400&fit=crop",
    passengers: 5,
    transmission: "Automatic",
    fuel: "Gasoline",
    ac: true,
    features: ["Bluetooth", "USB Charging", "Fuel Efficient"],
  },
  {
    id: 2,
    name: "Toyota RAV4",
    category: "suv",
    price: 55,
    image: "https://images.unsplash.com/photo-1568844293986-8c3a88e276c9?w=600&h=400&fit=crop",
    passengers: 5,
    transmission: "Automatic",
    fuel: "Gasoline",
    ac: true,
    features: ["All-Wheel Drive", "Spacious Trunk", "Apple CarPlay"],
  },
  {
    id: 3,
    name: "Toyota Camry",
    category: "sedan",
    price: 45,
    image: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=600&h=400&fit=crop",
    passengers: 5,
    transmission: "Automatic",
    fuel: "Gasoline",
    ac: true,
    features: ["Premium Sound", "Leather Seats", "GPS Navigation"],
  },
  {
    id: 4,
    name: "Jeep Wrangler",
    category: "suv",
    price: 85,
    image: "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=600&h=400&fit=crop",
    passengers: 4,
    transmission: "Automatic",
    fuel: "Gasoline",
    ac: true,
    features: ["4x4 Off-Road", "Convertible Top", "Adventure Ready"],
  },
  {
    id: 5,
    name: "Mercedes C-Class",
    category: "luxury",
    price: 120,
    image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=600&h=400&fit=crop",
    passengers: 5,
    transmission: "Automatic",
    fuel: "Gasoline",
    ac: true,
    features: ["Premium Luxury", "Heated Seats", "Premium Audio"],
  },
  {
    id: 6,
    name: "Chevrolet Spark",
    category: "economy",
    price: 25,
    image: "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=600&h=400&fit=crop",
    passengers: 4,
    transmission: "Manual",
    fuel: "Gasoline",
    ac: true,
    features: ["Compact", "Easy Parking", "Great MPG"],
  },
]

export function FleetSection() {
  const [activeCategory, setActiveCategory] = useState("all")

  const filteredVehicles = activeCategory === "all" 
    ? vehicles 
    : vehicles.filter(v => v.category === activeCategory)

  return (
    <section id="fleet" className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Our Fleet</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4 text-balance">
            Choose Your Perfect Vehicle
          </h2>
          <p className="text-muted-foreground text-lg">
            From compact economy cars to luxury SUVs, we have the perfect ride for every adventure in the Riviera Maya.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={cn(
                "px-6 py-2.5 rounded-full font-medium transition-all",
                activeCategory === category.id
                  ? "bg-primary text-primary-foreground shadow-lg"
                  : "bg-card text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              {category.label}
            </button>
          ))}
        </div>

        {/* Vehicle Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredVehicles.map((vehicle) => (
            <Card key={vehicle.id} className="overflow-hidden group hover:shadow-xl transition-all duration-300 border-0 bg-card">
              <div className="relative overflow-hidden">
                <img
                  src={vehicle.image}
                  alt={vehicle.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-semibold">
                  ${vehicle.price}/day
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold text-card-foreground">{vehicle.name}</h3>
                  <span className="text-xs uppercase tracking-wider text-muted-foreground bg-muted px-2 py-1 rounded">
                    {vehicle.category}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{vehicle.passengers} Passengers</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Settings className="h-4 w-4" />
                    <span>{vehicle.transmission}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Fuel className="h-4 w-4" />
                    <span>{vehicle.fuel}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Snowflake className="h-4 w-4" />
                    <span>A/C</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-5">
                  {vehicle.features.map((feature) => (
                    <span 
                      key={feature} 
                      className="text-xs bg-secondary text-secondary-foreground px-2.5 py-1 rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                <Button className="w-full bg-foreground hover:bg-foreground/90 text-background group/btn">
                  Book This Car
                  <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg" className="gap-2">
            View All Vehicles
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}
