import { MapPin, Clock, ArrowRight } from "lucide-react"

const destinations = [
  {
    name: "Tulum Ruins",
    distance: "65 km",
    time: "1 hour",
    image: "https://images.unsplash.com/photo-1518638150340-f706e86654de?w=600&h=800&fit=crop",
    description: "Ancient Mayan clifftop ruins overlooking the Caribbean Sea.",
  },
  {
    name: "Chichen Itza",
    distance: "180 km",
    time: "2.5 hours",
    image: "https://images.unsplash.com/photo-1518638150340-f706e86654de?w=600&h=800&fit=crop",
    description: "One of the New Seven Wonders of the World.",
  },
  {
    name: "Cenote Ik Kil",
    distance: "190 km",
    time: "2.5 hours",
    image: "https://images.unsplash.com/photo-1552061275-75f90131c6be?w=600&h=800&fit=crop",
    description: "Stunning underground swimming hole with hanging vines.",
  },
  {
    name: "Cozumel Island",
    distance: "20 km + ferry",
    time: "45 min",
    image: "https://images.unsplash.com/photo-1590523741831-ab7e8b8f9c7f?w=600&h=800&fit=crop",
    description: "World-class diving and snorkeling destination.",
  },
]

export function DestinationsSection() {
  return (
    <section id="destinations" className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Explore</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4 text-balance">
            Must-Visit Destinations Near Playa del Carmen
          </h2>
          <p className="text-muted-foreground text-lg">
            With your own rental car, discover the incredible beauty and history of the Yucatan Peninsula.
          </p>
        </div>

        {/* Destinations Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {destinations.map((destination, index) => (
            <div 
              key={index} 
              className="group relative h-96 rounded-2xl overflow-hidden cursor-pointer"
            >
              <img
                src={destination.image}
                alt={destination.name}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/90 via-foreground/40 to-transparent" />
              
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-xl font-bold text-background mb-2">{destination.name}</h3>
                <p className="text-background/80 text-sm mb-4 line-clamp-2">{destination.description}</p>
                
                <div className="flex items-center gap-4 text-sm text-background/70">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>{destination.distance}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{destination.time}</span>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2 text-primary font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Plan Your Trip</span>
                  <ArrowRight className="h-4 w-4" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center p-10 rounded-3xl bg-card border border-border">
          <h3 className="text-2xl font-bold text-card-foreground mb-4">
            Need Help Planning Your Itinerary?
          </h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Our local team can help you plan the perfect road trip through the Riviera Maya. 
            Get insider tips on the best routes, hidden cenotes, and local restaurants.
          </p>
          <a 
            href="#contact" 
            className="inline-flex items-center gap-2 text-primary font-semibold hover:underline"
          >
            Contact Our Team
            <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  )
}
