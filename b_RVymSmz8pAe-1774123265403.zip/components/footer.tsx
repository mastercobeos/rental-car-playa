import Link from "next/link"
import { Phone, Mail, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4">
        {/* Main Footer */}
        <div className="py-16 grid md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="/" className="inline-block mb-6">
              <div className="bg-background rounded-lg p-2">
                <svg viewBox="0 0 180 60" className="h-10 w-auto" fill="currentColor" style={{ color: 'var(--foreground)' }}>
                  <path d="M30 20c-3 0-5.5 1-7.5 3s-3 4.5-3 7.5 1 5.5 3 7.5 4.5 3 7.5 3h45c1.5-2 2.5-4.5 2.5-7s-1-5-2.5-7H30zm0 3h42c1 1.5 1.5 3 1.5 4.5S73 31 72 32.5H30c-2 0-3.5-.5-5-2s-2-3-2-5 .5-3.5 2-5 3-2 5-2z" />
                  <ellipse cx="35" cy="38" rx="6" ry="6" />
                  <ellipse cx="65" cy="38" rx="6" ry="6" />
                  <text x="90" y="25" fontSize="14" fontWeight="700" letterSpacing="2">PLAYA</text>
                  <text x="90" y="42" fontSize="10" fontWeight="400" letterSpacing="1">CAR RENTAL</text>
                </svg>
              </div>
            </Link>
            <p className="text-background/70 mb-6 text-sm leading-relaxed">
              Your trusted car rental partner in the Riviera Maya. Premium vehicles, transparent pricing, and exceptional service since 2018.
            </p>
            <div className="flex gap-4">
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-primary transition-colors"
                aria-label="Facebook"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-primary transition-colors"
                aria-label="Instagram"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
              <a 
                href="https://wa.me/529841234567" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-accent transition-colors"
                aria-label="WhatsApp"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-background text-lg mb-5">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <Link href="#fleet" className="text-background/70 hover:text-primary transition-colors">
                  Our Fleet
                </Link>
              </li>
              <li>
                <Link href="#features" className="text-background/70 hover:text-primary transition-colors">
                  Why Choose Us
                </Link>
              </li>
              <li>
                <Link href="#destinations" className="text-background/70 hover:text-primary transition-colors">
                  Destinations
                </Link>
              </li>
              <li>
                <Link href="#reviews" className="text-background/70 hover:text-primary transition-colors">
                  Customer Reviews
                </Link>
              </li>
              <li>
                <Link href="#faq" className="text-background/70 hover:text-primary transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-background/70 hover:text-primary transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Car Categories */}
          <div>
            <h4 className="font-semibold text-background text-lg mb-5">Car Categories</h4>
            <ul className="space-y-3">
              <li>
                <Link href="#fleet" className="text-background/70 hover:text-primary transition-colors">
                  Economy Cars
                </Link>
              </li>
              <li>
                <Link href="#fleet" className="text-background/70 hover:text-primary transition-colors">
                  SUVs & Crossovers
                </Link>
              </li>
              <li>
                <Link href="#fleet" className="text-background/70 hover:text-primary transition-colors">
                  Sedans
                </Link>
              </li>
              <li>
                <Link href="#fleet" className="text-background/70 hover:text-primary transition-colors">
                  Luxury Vehicles
                </Link>
              </li>
              <li>
                <Link href="#fleet" className="text-background/70 hover:text-primary transition-colors">
                  Vans & Minivans
                </Link>
              </li>
              <li>
                <Link href="#fleet" className="text-background/70 hover:text-primary transition-colors">
                  Convertibles
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold text-background text-lg mb-5">Contact Info</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-background/70 text-sm">
                  Playa del Carmen, Quintana Roo, Mexico 77710
                </span>
              </li>
              <li>
                <a href="tel:+529841234567" className="flex items-center gap-3 text-background/70 hover:text-primary transition-colors">
                  <Phone className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-sm">+52 984 123 4567</span>
                </a>
              </li>
              <li>
                <a href="mailto:info@playacarrental.com" className="flex items-center gap-3 text-background/70 hover:text-primary transition-colors">
                  <Mail className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-sm">info@playacarrental.com</span>
                </a>
              </li>
            </ul>
            
            <div className="mt-6 p-4 rounded-xl bg-background/5 border border-background/10">
              <p className="text-sm text-background/70">
                <span className="text-primary font-semibold">24/7 Support</span><br />
                Emergency roadside assistance available around the clock.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-6 border-t border-background/10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-background/50 text-sm">
              © 2026 Playa Car Rental. All rights reserved.
            </p>
            <div className="flex flex-wrap items-center gap-6 text-sm">
              <Link href="#" className="text-background/50 hover:text-primary transition-colors">
                Privacy Policy
              </Link>
              <Link href="#" className="text-background/50 hover:text-primary transition-colors">
                Terms of Service
              </Link>
              <Link href="#" className="text-background/50 hover:text-primary transition-colors">
                Rental Agreement
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
